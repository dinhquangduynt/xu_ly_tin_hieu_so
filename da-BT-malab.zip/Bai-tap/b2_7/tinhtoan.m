function [tong,nhan, n] = tinhtoan(a,b,m)
n = m;

tong = a + b;
nhan = a .* b;
end