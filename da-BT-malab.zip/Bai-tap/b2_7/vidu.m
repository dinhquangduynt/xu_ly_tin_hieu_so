n = -3:2;
x1 = [ 0 1, -1, 2, 3, -2];
x2 = [-2, -2, 1, 1, -4 0];

[tong, nhan, m] = tinhtoan(x1, x2, n);

subplot(211);
stem(m, tong);
title('x1(n) + x2(n)');

subplot(212);
stem(m, nhan);
title('x1(n) * x2(n)');

x(n)  -> H[(x(n)] = y(n); y(n-k);
x(n-k)  ->H(

